(function(){
var C=window.__C||{},P=window.__P||[],$=function(s){return Array.prototype.slice.call(document.querySelectorAll(s))};
var esc=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
var n=function(s){return s.replace(/\s+/g,' ').trim()};
var ST=['Склад в Китае','Отправлен в Россию','Таможня','Сортировка','Пункт выдачи'];
function api(m,u,b){return fetch(u,{method:m,headers:Object.assign({'X-Requested-With':'lc'},typeof b==='string'?{'Content-Type':'application/json'}:{}),body:b})
 .then(function(r){return r.json().catch(function(){return{}}).then(function(j){return Array.isArray(j)?j:Object.assign({ok:r.ok,status:r.status},j)})})}
function cards(){var g=document.getElementById('pgrid');if(g)g.innerHTML=P.map(function(p){return'<a class="pr" href="#"><div class="ph"'+(p.img?' style="background:url(\''+esc(p.img)+'\') center/cover"':'')+'><span class="new">NEW</span>'+(p.img?'':'<em>Фото товара</em>')+'</div><div class="cat">'+esc(p.cat)+'</div><div class="nm">'+esc(p.name)+'</div><div class="pc">'+esc(p.price||'[цена]')+' ₽</div></a>'}).join('')}
cards();
/* редактируемые тексты: ключ = блок страницы + номер внутри блока */
var SEL='.top,.bt,nav a,.eyebrow,h1 .ln span,.hero p,.btn,.strip span,h2,.all,.tile h3,.tile span,.st h3,.st p,.tr p,.ex,.pg h3,#sizes p,th,td,.cols h4,.cols a,.cols span,.cp span';
var els=$(SEL),cnt={},bar,edit=false;
els.forEach(function(e){var c=e.closest('.top,header,.hero,.strip,section,footer'),g=c.id||c.className.split(' ')[0]||c.tagName.toLowerCase();cnt[g]=cnt[g]||0;
 var k=g+'.'+cnt[g]++;e.dataset.edit=k;e.dataset.def=e.textContent;if(typeof C[k]==='string')e.textContent=C[k]});
var st=document.createElement('style');st.textContent=
'.lcm{position:fixed;inset:0;background:rgba(0,0,0,.6);display:grid;place-items:center;z-index:99;padding:16px}'+
'.lcm form{background:#fff;border:2px solid #0F0F0F;box-shadow:8px 8px 0 #FF9900;padding:24px;width:min(360px,100%);display:grid;gap:10px;font:14px Inter,sans-serif}'+
'.lcm h3{font:700 22px Oswald,sans-serif;text-transform:uppercase;margin:0}.lcm p{margin:0;font-size:12px;color:#555;min-height:16px}'+
'.lcm input{height:40px;border:1.5px solid #0F0F0F;padding:0 12px;font:inherit;border-radius:0}'+
'.lcm button{height:40px;border:1.5px solid #0F0F0F;background:#FF9900;font:700 12px Inter,sans-serif;cursor:pointer}.lcm button[type=button]{background:#fff}'+
'#lcb{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:96;background:#0F0F0F;border:2px solid #FF9900;display:flex;gap:6px;padding:8px;align-items:center;color:#fff;font:12px Inter,sans-serif;max-width:96vw;flex-wrap:wrap}'+
'#lcb button{height:32px;padding:0 12px;border:0;background:#FF9900;font:700 12px Inter,sans-serif;cursor:pointer}'+
'.lc-ed [data-edit]{outline:2px dashed #0a84ff;outline-offset:2px;cursor:text}#adm{color:#777}'+
'.lcp{position:fixed;inset:0;background:#F0F0EC;z-index:97;overflow:auto;font:13px Inter,sans-serif;color:#1a1a1a}'+
'.lch{position:sticky;top:0;z-index:2;background:#0F0F0F;color:#fff;display:flex;gap:6px;align-items:center;padding:calc(10px + env(safe-area-inset-top,0px)) 14px 10px;flex-wrap:wrap}'+
'.lch b{font:700 18px Oswald,sans-serif;text-transform:uppercase;margin-right:auto}.lcs{color:#FF9900;font-size:12px}'+
'.lch button{height:32px;padding:0 14px;border:1.5px solid #FF9900;background:transparent;color:#fff;font:600 12px Inter,sans-serif;cursor:pointer}.lch button.on{background:#FF9900;color:#0F0F0F}'+
'.lcb2{max-width:1100px;margin:0 auto;padding:18px 14px 40px}.lcf{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px}'+
'.lcp input,.lcp select{height:36px;border:1.5px solid #0F0F0F;background:#fff;padding:0 10px;font:inherit;border-radius:0;min-width:0}.lcf input{flex:1 1 160px}'+
'.lcp .lcf button,.lcp .row button{height:36px;border:1.5px solid #0F0F0F;background:#FF9900;font:700 12px Inter,sans-serif;padding:0 14px;cursor:pointer}.lcp .row button[data-d]{background:#fff}'+
'.row{display:flex;gap:6px;flex-wrap:wrap;align-items:center;background:#fff;border:1.5px solid #0F0F0F;padding:8px;margin-bottom:8px}.row b{font:600 15px Oswald,sans-serif;width:100px}.row input{flex:1 1 130px}'+
'.th{width:56px;height:56px;border:1.5px solid #0F0F0F;background:#E3E3DC center/cover;display:grid;place-items:center;font-size:10px;cursor:pointer}';
document.head.appendChild(st);

function panel(){
 if($('.lcp').length)return;
 var o=document.createElement('div');o.className='lcp';
 o.innerHTML='<div class="lch"><b>Управление магазином</b><span class="lcs"></span><button data-t="o">Посылки</button><button data-t="p">Товары</button><button data-x="1">Закрыть ✕</button></div><div class="lcb2"></div>';
 document.body.appendChild(o);document.body.style.overflow='hidden';
 var box=o.querySelector('.lcb2'),s=o.querySelector('.lcs'),tb=o.querySelectorAll('[data-t]');
 function ok(r,t){s.textContent=r&&r.ok===false?'Ошибка: '+(r.error||r.status):(t||'Сохранено ✓')}
 function tab(t){tb.forEach(function(b){b.className=b.dataset.t===t?'on':''});s.textContent='';(t==='o'?orders:products)()}
 o.querySelector('.lch').onclick=function(e){var d=e.target.dataset;if(d.t)tab(d.t);if(d.x){o.remove();document.body.style.overflow=''}};
 function orders(){
  box.innerHTML='<form class="lcf"><input name="customer" placeholder="Клиент"><input name="contact" placeholder="Telegram / телефон"><input name="item" placeholder="Что заказал" required><button>+ Создать посылку</button></form><div></div>';
  var f=box.firstChild,l=box.lastChild;
  function row(x){return'<div class="row" data-id="'+esc(x.id)+'"><b>'+esc(x.id)+'</b><input data-f="customer" value="'+esc(x.customer)+'" placeholder="Клиент"><input data-f="contact" value="'+esc(x.contact)+'" placeholder="Контакт"><input data-f="item" value="'+esc(x.item)+'" placeholder="Товар"><select data-f="stage">'+ST.map(function(t,i){return'<option value="'+i+'"'+(i===x.stage?' selected':'')+'>'+t+'</option>'}).join('')+'</select><button data-d="1">Удалить</button></div>'}
  function load(){api('GET','/api/orders').then(function(a){a=Array.isArray(a)?a:[];l.innerHTML=a.length?a.map(row).join(''):'<p>Посылок пока нет. Создайте первую выше.</p>'})}
  f.onsubmit=function(e){e.preventDefault();var b={};new FormData(f).forEach(function(v,k){b[k]=v});
   api('POST','/api/orders',JSON.stringify(b)).then(function(r){if(r.id){f.reset();ok(r,'Создана посылка '+r.id+' — сообщите номер клиенту');load()}else ok(r)})};
  l.onchange=function(e){var k=e.target.dataset.f,r=e.target.closest('.row');if(!k)return;var b={};b[k]=k==='stage'?+e.target.value:e.target.value;
   api('PUT','/api/orders/'+r.dataset.id,JSON.stringify(b)).then(function(x){ok(x)})};
  l.onclick=function(e){if(e.target.dataset.d&&confirm('Удалить посылку?'))api('DELETE','/api/orders/'+e.target.closest('.row').dataset.id).then(function(){ok({},'Удалено');load()})};
  load();
 }
 function products(){
  box.innerHTML='<form class="lcf"><button>+ Добавить товар</button></form><div></div>';
  var f=box.firstChild,l=box.lastChild;
  function draw(){l.innerHTML=P.length?P.map(function(p){return'<div class="row" data-id="'+esc(p.id)+'"><label class="th"'+(p.img?' style="background-image:url(\''+esc(p.img)+'\')"':'')+'>'+(p.img?'':'Фото')+'<input type="file" hidden data-up="1" accept="image/jpeg,image/png,image/webp"></label><input data-f="cat" value="'+esc(p.cat)+'" placeholder="Категория"><input data-f="name" value="'+esc(p.name)+'" placeholder="Название"><input data-f="price" value="'+esc(p.price)+'" placeholder="Цена, ₽"><button data-d="1">Удалить</button></div>'}).join(''):'<p>Товаров нет.</p>';cards()}
  function sync(){return fetch('/api/products').then(function(r){return r.json()}).then(function(a){P=a;draw()})}
  f.onsubmit=function(e){e.preventDefault();api('POST','/api/products').then(function(r){ok(r,'Товар добавлен');sync()})};
  l.onchange=function(e){var t=e.target,r=t.closest('.row'),b={};if(!r)return;
   if(t.dataset.up){var x=t.files[0];if(!x)return;if(x.size>5*1048576)return alert('Файл больше 5 МБ');
    api('POST','/api/upload',x).then(function(u){if(!u.url)return ok(u);api('PUT','/api/products/'+r.dataset.id,JSON.stringify({img:u.url})).then(function(){ok({});sync()})});return}
   if(!t.dataset.f)return;b[t.dataset.f]=t.value;
   api('PUT','/api/products/'+r.dataset.id,JSON.stringify(b)).then(function(x){ok(x);if(x.id)for(var i=0;i<P.length;i++)if(P[i].id===x.id)P[i]=x;cards()})};
  l.onclick=function(e){if(e.target.dataset.d&&confirm('Удалить товар?'))api('DELETE','/api/products/'+e.target.closest('.row').dataset.id).then(function(){ok({},'Удалено');sync()})};
  draw();
 }
 tab('o');
}

function admin(){
 if(bar)return;
 var acc=document.getElementById('acc');if(acc)acc.style.background='#FF9900';
 bar=document.createElement('div');bar.id='lcb';
 bar.innerHTML='<button data-a="p">Панель</button><button data-a="t">✎ Править тексты</button><button data-a="s" hidden>Сохранить</button><button data-a="o">Выйти</button><span></span>';
 document.body.appendChild(bar);
 var msg=bar.querySelector('span'),bs=bar.querySelector('[data-a=s]'),bt=bar.querySelector('[data-a=t]');
 bar.onclick=function(ev){var a=ev.target.dataset.a;
  if(a==='p')panel();
  if(a==='t'){edit=!edit;document.body.classList.toggle('lc-ed',edit);bs.hidden=!edit;bt.textContent=edit?'Готово':'✎ Править тексты';
   els.forEach(function(e){e.contentEditable=edit;e.spellcheck=false});msg.textContent=edit?'Кликайте по любому тексту':''}
  if(a==='s'){var d={};els.forEach(function(e){var v=n(e.textContent);if(v!==n(e.dataset.def))d[e.dataset.edit]=v});msg.textContent='Сохраняю…';
   api('PUT','/api/content',JSON.stringify(d)).then(function(r){msg.textContent=r.ok?'Сохранено ✓':(r.status===401?'Сессия истекла — войдите снова':'Ошибка сохранения')})}
  if(a==='o')api('POST','/api/logout').then(function(){location.reload()});
 };
}
document.addEventListener('keydown',function(e){if(edit&&e.key==='Enter'&&e.target.dataset&&e.target.dataset.edit)e.preventDefault()});
document.addEventListener('paste',function(e){if(edit&&e.target.dataset&&e.target.dataset.edit){e.preventDefault();document.execCommand('insertText',false,(e.clipboardData.getData('text/plain')||'').replace(/\s+/g,' '))}});
document.addEventListener('click',function(e){if(edit&&!e.target.closest('#lcb,.lcp,.lcm')&&e.target.closest('a'))e.preventDefault()},true);

function login(){
 if($('.lcm').length)return;
 var o=document.createElement('div');o.className='lcm';
 o.innerHTML='<form><h3>Вход для администратора</h3><p></p><input type="email" placeholder="Ваш e-mail" required autocomplete="email"><input type="text" hidden inputmode="numeric" maxlength="6" placeholder="Код из письма" autocomplete="one-time-code"><button>Получить код</button><button type="button">Закрыть</button></form>';
 document.body.appendChild(o);
 var f=o.firstChild,p=f.querySelector('p'),i=f.querySelectorAll('input'),b=f.querySelectorAll('button'),step=1;
 b[1].onclick=function(){o.remove()};i[0].focus();
 f.onsubmit=function(ev){ev.preventDefault();b[0].disabled=true;
  if(step===1)api('POST','/api/login',JSON.stringify({email:i[0].value})).then(function(r){b[0].disabled=false;
   if(!r.ok){p.textContent=r.error||'Ошибка';return}
   step=2;i[1].hidden=false;i[1].focus();b[0].textContent='Войти';p.textContent='Если адрес принадлежит администратору, на него отправлен код (действует 10 минут).'});
  else api('POST','/api/verify',JSON.stringify({email:i[0].value,code:i[1].value})).then(function(r){b[0].disabled=false;if(r.ok){o.remove();admin();panel()}else p.textContent=r.error||'Ошибка'});
 };
}
function openAcc(e){e.preventDefault();bar?panel():login()}
['acc','adm'].forEach(function(id){var a=document.getElementById(id);if(a)a.onclick=openAcc});
fetch('/api/me').then(function(r){return r.json()}).then(function(j){if(j.admin)admin();else if(location.hash==='#admin')login()}).catch(function(){});
})();
