const express=require('express'),crypto=require('crypto'),fs=require('fs'),path=require('path'),nodemailer=require('nodemailer');
const {PORT=3000,ADMIN_EMAIL='',SMTP_HOST,SMTP_PORT=465,SMTP_USER,SMTP_PASS,MAIL_FROM,DATA_DIR='data',NODE_ENV}=process.env;
const ADMIN=ADMIN_EMAIL.trim().toLowerCase();
if(!ADMIN){console.error('Укажите ADMIN_EMAIL в файле .env');process.exit(1)}
const D=path.resolve(DATA_DIR),UP=path.join(D,'uploads'),CF=path.join(D,'content.json'),SF=path.join(D,'secret');
fs.mkdirSync(UP,{recursive:true});
const SECRET=process.env.SESSION_SECRET||(fs.existsSync(SF)?fs.readFileSync(SF,'utf8'):(()=>{const s=crypto.randomBytes(32).toString('hex');fs.writeFileSync(SF,s,{mode:0o600});return s})());
const hmac=s=>crypto.createHmac('sha256',SECRET).update(s).digest('base64url');
const sign=()=>{const p=Buffer.from(JSON.stringify({e:ADMIN,x:Date.now()+7*864e5})).toString('base64url');return p+'.'+hmac(p)};
function isAdmin(req){
  const m=(req.headers.cookie||'').match(/(?:^|; )lc=([^;]+)/);if(!m)return false;
  const [p,s]=m[1].split('.');if(!p||!s)return false;
  const a=Buffer.from(hmac(p)),b=Buffer.from(s);
  if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return false;
  try{const j=JSON.parse(Buffer.from(p,'base64url'));return j.e===ADMIN&&j.x>Date.now()}catch{return false}
}
const read=()=>{try{return JSON.parse(fs.readFileSync(CF,'utf8'))}catch{return{}}};
const tx=SMTP_HOST?nodemailer.createTransport({host:SMTP_HOST,port:+SMTP_PORT,secure:+SMTP_PORT===465,auth:{user:SMTP_USER,pass:SMTP_PASS}}):null;
const codes=new Map(),hits=new Map();
function limited(k,n,ms){const t=Date.now(),a=(hits.get(k)||[]).filter(x=>t-x<ms);a.push(t);hits.set(k,a);return a.length>n}

const app=express();app.set('trust proxy',1);app.disable('x-powered-by');
app.use((req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'same-origin'});next()});
app.use('/api',(req,res,next)=>{
  if(req.method!=='GET'){
    const o=req.headers.origin;
    if(req.headers['x-requested-with']!=='lc'||(o&&o!==`${req.protocol}://${req.get('host')}`))return res.status(403).json({error:'forbidden'});
  }
  res.set('Cache-Control','no-store');next();
});
app.use('/api',express.json({limit:'200kb'}));

app.post('/api/login',(req,res)=>{
  const email=String((req.body||{}).email||'').trim().toLowerCase();
  res.json({ok:true}); // одинаковый ответ для любого адреса
  if(email!==ADMIN||limited('l'+req.ip,10,3600e3))return;
  const old=codes.get(email);if(old&&Date.now()-old.t<60e3)return;
  const code=String(crypto.randomInt(0,1e6)).padStart(6,'0');
  codes.set(email,{h:hmac(code),x:Date.now()+600e3,t:Date.now(),n:0});
  if(!tx)return console.log('КОД ВХОДА (SMTP не настроен):',code);
  tx.sendMail({from:MAIL_FROM||SMTP_USER,to:ADMIN,subject:'Код входа Logistic Center',
    text:`Ваш код: ${code}\nОн действует 10 минут. Если вы не запрашивали вход — проигнорируйте письмо.`})
    .catch(e=>console.error('Ошибка отправки письма:',e.message));
});
app.post('/api/verify',(req,res)=>{
  if(limited('v'+req.ip,20,3600e3))return res.status(429).json({error:'Слишком много попыток, попробуйте позже'});
  const b=req.body||{},email=String(b.email||'').trim().toLowerCase(),code=String(b.code||'').trim(),c=codes.get(email);
  if(!c||c.x<Date.now()||c.n>=5){codes.delete(email);return res.status(400).json({error:'Код недействителен. Запросите новый.'})}
  c.n++;
  if(!crypto.timingSafeEqual(Buffer.from(hmac(code)),Buffer.from(c.h)))return res.status(400).json({error:'Неверный код'});
  codes.delete(email);
  res.set('Set-Cookie',`lc=${sign()}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800${NODE_ENV==='production'?'; Secure':''}`);
  res.json({ok:true});
});
app.post('/api/logout',(req,res)=>{res.set('Set-Cookie','lc=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');res.json({ok:true})});
app.get('/api/me',(req,res)=>res.json({admin:isAdmin(req)}));
app.put('/api/content',(req,res)=>{
  if(!isAdmin(req))return res.status(401).json({error:'auth'});
  const b=req.body,o={};if(!b||typeof b!=='object')return res.status(400).json({error:'bad'});
  for(const [k,v] of Object.entries(b)){
    if(/^[\w-]{1,24}\.\d{1,3}$/.test(k)&&typeof v==='string'&&v.length<=600)o[k]=v;
  }
  fs.writeFileSync(CF,JSON.stringify(o));res.json({ok:true});
});
const EXT={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
app.post('/api/upload',express.raw({type:Object.keys(EXT),limit:'5mb'}),(req,res)=>{
  if(!isAdmin(req))return res.status(401).json({error:'auth'});
  const e=EXT[req.headers['content-type']];
  if(!e||!Buffer.isBuffer(req.body)||!req.body.length)return res.status(400).json({error:'Нужен JPG, PNG или WebP до 5 МБ'});
  const n=crypto.randomBytes(8).toString('hex')+'.'+e;fs.writeFileSync(path.join(UP,n),req.body);res.json({url:'/uploads/'+n});
});


const J=(f,d)=>{try{return JSON.parse(fs.readFileSync(path.join(D,f),'utf8'))}catch{return d}};
const W=(f,v)=>fs.writeFileSync(path.join(D,f),JSON.stringify(v));
const rid=()=>crypto.randomBytes(4).toString('hex');
const SEED=[['Худи','Худи оверсайз'],['Обувь','Кроссовки на платформе'],['Штаны','Карго-штаны'],['Куртки','Куртка-бомбер']].map(([cat,name])=>({id:rid(),cat,name,price:'',img:''}));
const prods=()=>{const p=J('products.json',null);if(p)return p;W('products.json',SEED);return SEED};
const need=(req,res,next)=>isAdmin(req)?next():res.status(401).json({error:'auth'});
const S=(v,n=120)=>typeof v==='string'?v.trim().slice(0,n):'';
const IMG=/^\/uploads\/[\w-]+\.(jpg|png|webp)$/;
// ---- посылки (только админ) ----
app.get('/api/orders',need,(q,r)=>r.json(J('orders.json',[])));
app.post('/api/orders',need,(req,res)=>{
  const o=J('orders.json',[]),b=req.body||{};
  const x={id:'LC-'+String(o.reduce((m,i)=>Math.max(m,+i.id.slice(3)),0)+1).padStart(6,'0'),customer:S(b.customer),contact:S(b.contact),item:S(b.item),stage:0,created:new Date().toISOString()};
  if(!x.customer&&!x.item)return res.status(400).json({error:'Заполните клиента или товар'});
  o.unshift(x);W('orders.json',o);res.json(x);
});
app.put('/api/orders/:id',need,(req,res)=>{
  const o=J('orders.json',[]),x=o.find(i=>i.id===req.params.id),b=req.body||{};
  if(!x)return res.status(404).json({error:'Не найдено'});
  for(const k of['customer','contact','item'])if(k in b)x[k]=S(b[k]);
  if(Number.isInteger(b.stage)&&b.stage>=0&&b.stage<=4)x.stage=b.stage;
  W('orders.json',o);res.json(x);
});
app.delete('/api/orders/:id',need,(req,res)=>{W('orders.json',J('orders.json',[]).filter(i=>i.id!==req.params.id));res.json({ok:true})});
// публичная проверка статуса: отдаём только этап, без личных данных
app.post('/api/track',(req,res)=>{
  if(limited('t'+req.ip,30,3600e3))return res.status(429).json({error:'Слишком много запросов'});
  const id=String((req.body||{}).id||'').trim().toUpperCase(),x=J('orders.json',[]).find(i=>i.id===id);
  res.json(x?{stage:x.stage}:{});
});
// ---- товары ----
app.get('/api/products',(q,r)=>r.json(prods()));
app.post('/api/products',need,(req,res)=>{const p=prods(),x={id:rid(),cat:'Категория',name:'Новый товар',price:'',img:''};p.push(x);W('products.json',p);res.json(x)});
app.put('/api/products/:id',need,(req,res)=>{
  const p=prods(),x=p.find(i=>i.id===req.params.id),b=req.body||{};
  if(!x)return res.status(404).json({error:'Не найдено'});
  for(const k of['cat','name'])if(k in b)x[k]=S(b[k],80);
  if('price' in b)x.price=S(b.price,20);
  if('img' in b&&(b.img===''||(typeof b.img==='string'&&IMG.test(b.img))))x.img=b.img;
  W('products.json',p);res.json(x);
});
app.delete('/api/products/:id',need,(req,res)=>{W('products.json',prods().filter(i=>i.id!==req.params.id));res.json({ok:true})});

app.get('/',(req,res)=>{
  const c=JSON.stringify(read()).replace(/</g,'\\u003c');
  res.type('html').send(fs.readFileSync(path.join(__dirname,'public/index.html'),'utf8').replace('<!--CONTENT-->',`<script>window.__C=${c};window.__P=${JSON.stringify(prods()).replace(/</g,'\\u003c')}</script>`));
});
app.get('/index.html',(req,res)=>res.redirect('/'));
app.use('/uploads',express.static(UP,{maxAge:'7d'}));
app.use(express.static(path.join(__dirname,'public'),{index:false}));
app.listen(PORT,()=>console.log(`Сайт: http://localhost:${PORT}  (админ: ${ADMIN})`));
